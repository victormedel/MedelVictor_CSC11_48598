Compile Instructions

as -o project2.o project2.s
gcc -o project2 project2.o